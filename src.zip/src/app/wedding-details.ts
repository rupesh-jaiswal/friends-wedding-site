export const weddingdetails={
	coupleName: 'Mitali & Amol',
	weddingDate: '04.12.2017',
	weddingCeremonyTime: '5:00 pm',
	receptionDinnerTime: '7:00 pm',
	weddingAddress: 'Madh Island, Mumbai',
	engagementDate: '28.04-17'
}